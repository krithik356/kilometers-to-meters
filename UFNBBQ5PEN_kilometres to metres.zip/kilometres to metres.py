a=float(input())
print(a*1000)